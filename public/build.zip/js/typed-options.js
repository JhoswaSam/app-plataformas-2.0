 /*-------------------------------------------------------------------------------
    Home Typed - Typed js
  -------------------------------------------------------------------------------*/

  $(function(){
    $(".element").typed({
      strings: ["Floren Creative Agency",
                        "We build websites",
                        "Web . Mobile Studio"],
                    typeSpeed: 100,
                     contentType: 'html',
                     showCursor: false,
                     loop: true,
                     loopCount: true,
      });
    });