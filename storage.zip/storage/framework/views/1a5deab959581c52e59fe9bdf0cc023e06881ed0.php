;

<?php $__env->startSection('contenido'); ?>
    <div class="container-fluid">
        <h1><?php echo e($ong->id); ?></h1>
        <h1><?php echo e($ong->nombreOng); ?></h1>
        <h1><?php echo e($ong->descripcionOng); ?></h1>
        
        <a href="./<?php echo e($ong->id); ?>/donar" class="btn btn-primary">Donar</a>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/client/descriptionong.blade.php ENDPATH**/ ?>