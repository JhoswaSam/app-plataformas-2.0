

<?php $__env->startSection('css'); ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css"> 

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.css">

    <!-- Font Awesome Icons CSS 
    <link rel="stylesheet" href="css/font-awesome.min.css">-->

    <!-- Magnific-popup CSS -->
    <link rel="stylesheet" href="css/magnific-popup.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu-active'); ?>
    <li><a href="/">Inicio</a></li>
    <li class="active"><a href="/about">Nosotros</a></li>
    <li><a href="/services">Ongs</a></li>
    <li><a href="work.html">Obras</a></li>
    <li><a href="contact.html">Contactenos</a></li>
    
        <?php if(Route::has('login')): ?>   
            <?php if(auth()->guard()->check()): ?>
                <?php if($user->usuario): ?>
                    <li>
                        <a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e(url('/profile/client')); ?>"><?php echo e(__('Perfil')); ?></a>
                    </li>
                
                    <!-- Authentication -->
                    <li>
                        <form style="margin-top: 14%" method="POST" action="<?php echo e(url('/logout2')); ?>" x-data>
                            <?php echo csrf_field(); ?>
                            <a href="<?php echo e(url('/logout2')); ?>" @click.prevent="$root.submit();"><?php echo e(__('Salir')); ?></a>
                        </form>
                    </li>

                <?php endif; ?>
            <?php else: ?>
                <li>
                    <a href="<?php echo e(route('login')); ?>" >Iniciar Sesión</a>
                </li>

            <?php if(Route::has('register')): ?>
                <li>
                    <a href="<?php echo e(route('register')); ?>" >Registrarse</a>
                </li>
            <?php endif; ?>

            <?php endif; ?>
        <?php endif; ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <!-- Home Section -->

    <section id="home" class="main-about">
        <div class="container">
            <div class="row">

                <div class="col-md-12 col-sm-12">
                    <h1 class="wow fadeInUp head" data-wow-delay="0.6s">Tabaco y Channel</h1>
                    <p class="wow fadeInUp lr-pd" data-wow-delay="0.8s">Somos un grupo de estudiantes que busca realizar una proyecto que ayude a la sociedad, este es el proyecto donde podras conocer a las ongs y poder donarles de manera segura.</p>
                </div>

            </div>
        </div>
    </section>

    <!-- About Section -->

    


    <!-- Team Section -->

    <section id="team">
        <div class="container">
            <div class="row">

                <div class="col-md-12 col-sm-12">
                    <div class="wow bounceIn section-title">
                        <h2>Nuestro equipo</h2>
                    </div>
                </div>

                <div class="wow fadeInUp col-md-4 col-sm-6" data-wow-delay="0.4s">
                    <div class=" portfolio-thumb team-thumb">
                        <img src="img/aldy2.jpg" class="img-responsive" alt="Team">
                            <div class="team-overlay">
                                <h3>Aldeyny V. G. P.</h3>
                                <h4>Scrum Master</h4>
                                <ul class="social-icon">
                                    <li><a href="#" class="fa fa-facebook"></a></li>
                                    <li><a href="#" class="fa fa-twitter"></a></li>
                                    <li><a href="#" class="fa fa-google-plus"></a></li>
                                </ul>
                            </div>
                    </div>
                </div>

                <div class="wow fadeInUp col-md-4 col-sm-6" data-wow-delay="0.4s">
                    <div class="portfolio-thumb team-thumb">
                        <img src="img/kel2.jpg" class="img-responsive" alt="Team">
                            <div class="team-overlay">
                                <h3>Kelma S. M.</h3>
                                <h4>UI Designer</h4>
                                <ul class="social-icon">
                                    <li><a href="#" class="fa fa-facebook"></a></li>
                                    <li><a href="#" class="fa fa-twitter"></a></li>
                                    <li><a href="#" class="fa fa-google-plus"></a></li>
                                </ul>
                            </div>
                    </div>
                </div>

                <div class="wow fadeInUp col-md-4 col-sm-6" data-wow-delay="0.4s">
                    <div class="portfolio-thumb team-thumb">
                        <img src="img/edu.jpg" class="img-responsive" alt="Team">
                            <div class="team-overlay">
                                <h3>H. Eduardo Q. L.</h3>
                                <h4>UI Designer</h4>
                                <ul class="social-icon">
                                    <li><a href="#" class="fa fa-facebook"></a></li>
                                    <li><a href="#" class="fa fa-twitter"></a></li>
                                    <li><a href="#" class="fa fa-google-plus"></a></li>
                                </ul>
                            </div>
                    </div>
                </div>

                <div class="wow fadeInUp col-md-4 col-sm-6" data-wow-delay="0.6s">
                    <div class="portfolio-thumb team-thumb">
                        <img src="img/mila2.jpg" class="img-responsive" alt="Team">
                            <div class="team-overlay">
                                <h3>Milagros A. A. M.</h3>
                                <h4>UI Designer</h4>
                                <ul class="social-icon">
                                    <li><a href="#" class="fa fa-facebook"></a></li>
                                    <li><a href="#" class="fa fa-twitter"></a></li>
                                </ul>
                            </div>
                    </div>
                </div>

                <div class="wow fadeInUp col-md-4 col-sm-6" data-wow-delay="0.8s">
                    <div class="portfolio-thumb team-thumb">
                        <img src="img/jhos3.jpg" class="img-responsive" alt="Team">
                            <div class="team-overlay">
                                <h3>Jhoswa S.</h3>
                                <h4>Programmer</h4>
                                <ul class="social-icon">
                                    <li><a href="#" class="fa fa-facebook"></a></li>
                                    <li><a href="#" class="fa fa-twitter"></a></li>
                                    <li><a href="#" class="fa fa-google-plus"></a></li>
                                </ul>
                            </div>
                    </div>
                </div>

                <div class="wow fadeInUp col-md-4 col-sm-6" data-wow-delay="0.8s">
                    <div class="portfolio-thumb team-thumb">
                        <img src="img/alex.jpg" class="img-responsive" alt="Team">
                            <div class="team-overlay">
                                <h3>Alexander S.</h3>
                                <h4>Programmer</h4>
                                <ul class="social-icon">
                                    <li><a href="#" class="fa fa-facebook"></a></li>
                                    <li><a href="#" class="fa fa-twitter"></a></li>
                                    <li><a href="#" class="fa fa-google-plus"></a></li>
                                </ul>
                            </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.easypiechart.min.js"></script>
    <script src="js/custom.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/test/about.blade.php ENDPATH**/ ?>