

<?php $__env->startSection('css'); ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css"> 

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.css">

    <!-- Font Awesome Icons CSS 
    <link rel="stylesheet" href="css/font-awesome.min.css">-->

    <!-- Magnific-popup CSS -->
    <link rel="stylesheet" href="css/magnific-popup.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu-active'); ?>
    <li><a href="/">Inicio</a></li>
    <li><a href="/about">Nosotros</a></li>
    <li><a href="/services">Ongs</a></li>
    <li class="active"><a href="/contact">Contactenos</a></li>
    
        <?php if(Route::has('login')): ?>   
            <?php if(auth()->guard()->check()): ?>
                <?php if($user->usuario): ?>
                    <li>
                        <a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e(url('/profile/client')); ?>"><?php echo e(__('Perfil')); ?></a>
                    </li>
                
                    <!-- Authentication -->
                    <li>
                        <form style="margin-top: 20%" method="POST" action="<?php echo e(url('/logout2')); ?>" x-data>
                            <?php echo csrf_field(); ?>
                            <a href="<?php echo e(url('/logout2')); ?>" @click.prevent="$root.submit();"><?php echo e(__('Salir')); ?></a>
                        </form>
                    </li>

                <?php endif; ?>
            <?php else: ?>
                <li>
                    <a href="<?php echo e(route('login')); ?>" >Iniciar Sesión</a>
                </li>

            <?php if(Route::has('register')): ?>
                <li>
                    <a href="<?php echo e(route('register')); ?>" >Registrarse</a>
                </li>
            <?php endif; ?>

            <?php endif; ?>
        <?php endif; ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <!-- Home Section -->

    <section id="home" class="main-contact">
        <div class="container">
            <div class="row">

                <div class="col-md-12 col-sm-12">
                    <h1 class="wow fadeInUp head" data-wow-delay="0.6s">Contactenos</h1>
                    <p class="wow fadeInUp lr-pd" data-wow-delay="0.8s">Si tiene algun comentario o queja o quiere trabajar con nosotros llene este formulario y nosotros esteremos en contacto con usted lo mas antes posible.</p>
                </div>

            </div>
        </div>
    </section>


    <!-- Contact Section -->

    <section id="contact">
        <div class="container">
            <div class="row">
                
                <div class="wow fadeInUp col-md-4 col-sm-4" data-wow-delay="0.6s">
                    <div class="contact-detail">

                        <div class="contact-detail-1">
                            <h3>Cusco</h3>
                            <p class="small">Urb. Ingeniería Larapa Grande A-7</p>
                            <p class="small">+51 999 999 999 / +51 999 999 998</p>
                            <p class="small">service@tabacoychannel.com</p>
                        </div>

                    </div>
                </div>

                <div class="wow fadeInUp col-md-8 col-sm-8" data-wow-delay="0.4s">
                    <form action="contact.php" method="post">
                        <div class="col-md-6 col-sm-6">
                            <input type="text" class="form-control" placeholder="Nombre" required>
                        </div>

                        <div class="col-md-6 col-sm-6">
                            <input type="email" class="form-control" placeholder="Correo" required>
                        </div>

                        <div class="col-md-12 col-sm-12">
                            <input type="tel" class="form-control" placeholder="Tu telefono" required>
                            <textarea class="form-control" placeholder="Tu mensaje" rows="6" required></textarea>
                        </div>

                        <div class="col-md-4 col-sm-6">
                            <input type="submit" class="form-control" value="Enviar">
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/custom.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/test/contact.blade.php ENDPATH**/ ?>