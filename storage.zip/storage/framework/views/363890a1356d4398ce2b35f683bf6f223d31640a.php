

<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('header', null, []); ?> 
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Editar Ong')); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg " style="padding: 3%;">
                    
                    
                    <div class="formbg">
                        <div class="padding-horizontal--48">
                            <form action="/ongs/<?php echo e($ong->id); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                
                                <div class="field padding-bottom--24">
                                    <label for="" class="form-label">Categoria</label>
                                    <select  name="categoria" id="categoria">
                                            <option value="<?php echo e($ong->categoria->id); ?>"><?php echo e($ong->categoria->nombreCad); ?></option>
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombreCad); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="field padding-bottom--24">
                                    <label for="" class="form-label">Nombre</label>
                                    <input id="nombre" name="nombre" type="text" class="form-control" tabindex="2" value="<?php echo e($ong->nombreOng); ?>">
                                </div>
                                <div class="field padding-bottom--24">
                                    <label for="" class="form-label">Contacto</label>
                                    <input id="contacto" name="contacto" type="text" class="form-control" tabindex="2" value="<?php echo e($ong->nombreContacto); ?>">
                                </div>
                                <div class="field padding-bottom--24">
                                    <label for="" class="form-label">Direccion</label>
                                    <input id="direccion" name="direccion" type="text" class="form-control" tabindex="2" value="<?php echo e($ong->direccionOng); ?>">
                                </div>
                                <div class="field padding-bottom--24">
                                    <label for="" class="form-label">Telefono</label>
                                    <input id="telefono" name="telefono" type="text" class="form-control" tabindex="2" value="<?php echo e($ong->telefonoOng); ?>">
                                </div>
                                <div class="field padding-bottom--24">
                                    <label for="" class="form-label">Descripcion</label>
                                    <input id="descripcion" name="descripcion" type="text" class="form-control" tabindex="2" value="<?php echo e($ong->descripcionOng); ?>">
                                </div>
                                <div class="field padding-bottom--24">
                                    <label for="" class="form-label">Correo</label>
                                    <input id="correo" name="correo" type="text" class="form-control" tabindex="2" value="<?php echo e($ong->correoOng); ?>">
                                </div>

                                <div class="field padding-bottom--24">
                                    <label for="" class="form-label">Foto</label>
                                    <img src="<?php echo e(asset($ong->fotoOng)); ?>" alt="<?php echo e($ong->nombreOng); ?>">
                                    <input id="foto" name="foto" type="file" class="form-control" accept="image/*" tabindex="2">
                                </div>


                                <div class="field padding-bottom--24">
                                    <label for="" class="form-label">Estado</label>
                        
                                    <select  name="estado" id="estado">
                                        <?php if($ong->estadoOng): ?>
                                            <option value="<?php echo e($ong->estadoOng); ?>">Activo</option>
                                        <?php else: ?>
                                            <option value="<?php echo e($ong->estadoOng); ?>">Inactivo</option>
                                        <?php endif; ?>
                                        <option value="1">Activo</option>
                                        <option value="0">Inactivo</option>
                                      </select>
                                </div>
                        
                                <a href="/ongs" class="btn-cancelar" tabindex="5">Cancelar</a>
                                <button type="submit" class="btn-guardar" tabindex="4">Guardar</button>
                            </form>
                            
                      </div>
                    </div>



                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.create-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/ong/edit.blade.php ENDPATH**/ ?>