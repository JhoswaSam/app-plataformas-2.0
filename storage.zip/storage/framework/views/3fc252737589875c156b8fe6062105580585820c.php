

<?php $__env->startSection('css'); ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css"> 

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.css">

    <!-- Font Awesome Icons CSS 
    <link rel="stylesheet" href="css/font-awesome.min.css">-->

    <!-- Magnific-popup CSS -->
    <link rel="stylesheet" href="css/magnific-popup.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu-active'); ?>
    <li><a href="/">Inicio</a></li>
    <li><a href="/about">Nosotros</a></li>
    <li><a href="/services">Ongs</a></li>
    <li class="active"><a href="/work">Obras</a></li>
    <li><a href="contact.html">Contactenos</a></li>
    
        <?php if(Route::has('login')): ?>   
            <?php if(auth()->guard()->check()): ?>
                <?php if($user->usuario): ?>
                    <li>
                        <a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e(url('/profile/client')); ?>"><?php echo e(__('Perfil')); ?></a>
                    </li>
                
                    <!-- Authentication -->
                    <li>
                        <form style="margin-top: 20%" method="POST" action="<?php echo e(url('/logout2')); ?>" x-data>
                            <?php echo csrf_field(); ?>
                            <a href="<?php echo e(url('/logout2')); ?>" @click.prevent="$root.submit();"><?php echo e(__('Salir')); ?></a>
                        </form>
                    </li>

                <?php endif; ?>
            <?php else: ?>
                <li>
                    <a href="<?php echo e(route('login')); ?>" >Iniciar Sesión</a>
                </li>

            <?php if(Route::has('register')): ?>
                <li>
                    <a href="<?php echo e(route('register')); ?>" >Registrarse</a>
                </li>
            <?php endif; ?>

            <?php endif; ?>
        <?php endif; ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

     <!-- Home Section -->

     <section id="home" class="main-work">
        <div class="container">
            <div class="row">

                <div class="col-md-12 col-sm-12">
                        <h1 class="wow fadeInUp head" data-wow-delay="0.6s">Our Showcase</h1>
                        <p class="wow fadeInUp lr-pd" data-wow-delay="0.8s">We help Brands and Businesses build communication across Web, Print and Digital Medium.</p>
                   </div>

            </div>
        </div>
    </section>


    <!-- Portfolio Section -->

    <section id="portfolio">
        <div class="container">
            <div class="row">

                <div class="col-md-12 col-sm-12">

                    <!-- work section -->
                        <div class="work-section wow fadeInUp" data-wow-delay="1s">

                            <ul class="filter-wrapper clearfix">
                                 <li><a href="#" data-filter="*" class="selected opc-main-bg">Show All</a></li>
                                 <li><a href="#" class="opc-main-bg" data-filter=".web">Web Design</a></li>
                                 <li><a href="#" class="opc-main-bg" data-filter=".photoshop">Photoshop</a></li>
                                 <li><a href="#" class="opc-main-bg" data-filter=".branding">Branding</a></li>
                                 <li><a href="#" class="opc-main-bg" data-filter=".mobile">Mobile App</a></li>
                                <li><a href="#" class="opc-main-bg" data-filter=".html">HTML Templates</a></li>
                            </ul>

                            <!-- work box section -->
                            <div class="work-box-section wow fadeInUp" data-wow-delay="1.4s">
                                <div class="work-box-wrapper col4-work-box">

                                    <div class="work-box graphic photoshop branding html col-md-4 col-sm-6">
                                        <div class="portfolio-thumb">
                                            <a href="img/portfolio-img1.jpg" class="image-popup">
                                                <div class="portfolio-item-hover">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <img src="img/portfolio-img1.jpg" class="img-responsive" alt="Portfolio">
                                            </a>
                                        </div>
                                    </div>

                                    <div class="work-box graphic photoshop col-md-4 col-sm-6">
                                        <div class="portfolio-thumb">
                                            <a href="img/portfolio-img2.jpg" class="image-popup">
                                                <div class="portfolio-item-hover">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <img src="img/portfolio-img2.jpg" class="img-responsive" alt="Portfolio">
                                            </a>
                                        </div>
                                    </div>

                                    <div class="work-box branding mobile col-md-4 col-sm-6">
                                        <div class="portfolio-thumb">
                                            <a href="img/portfolio-img3.jpg" class="image-popup">
                                                <div class="portfolio-item-hover">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <img src="img/portfolio-img3.jpg" class="img-responsive" alt="Portfolio">
                                            </a>
                                        </div>
                                    </div>

                                    <div class="work-box graphic mobile col-md-4 col-sm-6">
                                        <div class="portfolio-thumb">
                                            <a href="img/portfolio-img4.jpg" class="image-popup">
                                                <div class="portfolio-item-hover">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <img src="img/portfolio-img4.jpg" class="img-responsive" alt="Portfolio">
                                            </a>
                                        </div>
                                    </div>

                                    <div class="work-box web mobile col-md-4 col-sm-6">
                                        <div class="portfolio-thumb">
                                            <a href="img/portfolio-img5.jpg" class="image-popup">
                                                <div class="portfolio-item-hover">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <img src="img/portfolio-img5.jpg" class="img-responsive" alt="Portfolio">
                                            </a>
                                        </div>
                                    </div>

                                    <div class="work-box web photoshop col-md-4 col-sm-6">
                                        <div class="portfolio-thumb">
                                            <a href="img/portfolio-img6.jpg" class="image-popup">
                                                <div class="portfolio-item-hover">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <img src="img/portfolio-img6.jpg" class="img-responsive" alt="Portfolio">
                                            </a>
                                        </div>
                                    </div>

                                    <div class="work-box web html col-md-4 col-sm-6">
                                        <div class="portfolio-thumb">
                                            <a href="img/portfolio-img7.jpg" class="image-popup">
                                                <div class="portfolio-item-hover">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <img src="img/portfolio-img7.jpg" class="img-responsive" alt="Portfolio">
                                            </a>
                                        </div>
                                    </div>

                                    <div class="work-box graphic photoshop col-md-4 col-sm-6">
                                        <div class="portfolio-thumb">
                                            <a href="img/portfolio-img8.jpg" class="image-popup">
                                                <div class="portfolio-item-hover">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <img src="img/portfolio-img8.jpg" class="img-responsive" alt="Portfolio">
                                            </a>
                                        </div>
                                    </div>

                                    <div class="work-box web photoshop col-md-4 col-sm-6">
                                        <div class="portfolio-thumb">
                                            <a href="img/portfolio-img9.jpg" class="image-popup">
                                                <div class="portfolio-item-hover">
                                                    <i class="fa fa-plus"></i>
                                                </div>
                                                <img src="img/portfolio-img9.jpg" class="img-responsive" alt="Portfolio">
                                            </a>
                                        </div>
                                    </div>

                                 </div>
                            </div>

                        </div>

                </div>

            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/isotope.js"></script>
    <script src="js/imagesloaded.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/magnific-popup-options.js"></script>
    <script src="js/custom.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/test/works.blade.php ENDPATH**/ ?>