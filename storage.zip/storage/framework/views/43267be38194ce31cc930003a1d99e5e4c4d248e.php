;

<?php $__env->startSection('contenido'); ?>
    <div class="container-fluid">
        <h1>Donar <?php echo e($ong->nombreOng); ?></h1>
        <form action="./donar/<?php echo e($idClient=1); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="" class="form-label">Cantidad</label>
                <input id="cantidad" name="cantidad" value="0.00" type="number" class="form-control" tabindex="2">
            </div>
            <div class="mb-3">
                <label for="" class="form-label">Descripcion</label>
                <input id="descripcion" name="descripcion" type="text" class="form-control" tabindex="2">
            </div>

            <a href="/list" class="btn btn-secondary" tabindex="5">Cancelar</a>
            <button type="submit" class="btn btn-primary" tabindex="4">Guardar</button>
        </form>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/client/donation.blade.php ENDPATH**/ ?>