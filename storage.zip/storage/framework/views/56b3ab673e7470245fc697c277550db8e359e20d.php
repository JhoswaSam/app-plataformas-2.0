


<?php $__env->startSection('contenido'); ?>
    <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('header', null, []); ?> 
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Donativos')); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg" style="padding: 3%">
                    <a href="donativos/create" class="btn-create">CREAR</a>

                    <table id="donativos" style="width: 100%">
                        <thead style="background-color: #d3d4df;">
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Usuario</th>
                                <th scope="col">Ong</th>
                                <th scope="col">Cantidad</th>
                                <th scope="col">Descripcion</th>
                                <th scope="col">Creacion</th>
                                <th scope="col">Actualizacion</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody style="background-color: #ebebef;">
                            <?php $__currentLoopData = $donativos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donativo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($donativo->id); ?></td>
                                    <td><?php echo e($donativo->usuario->id); ?></td>
                                    <td><?php echo e($donativo->ong->nombreOng); ?></td>
                                    <td><?php echo e($donativo->cantidadDon); ?></td>
                                    <td><?php echo e($donativo->descripcionDon); ?></td>
                                    <td><?php echo e($donativo->created_at); ?></td>
                                    <td><?php echo e($donativo->updated_at); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('donativos.destroy',$donativo->id)); ?>" method="POST">
                                            <a class="btn-editar" href="/donativos/<?php echo e($donativo->id); ?>/edit">Editar</a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn-borrar">Borrar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
        $('#donativos').DataTable({
            "lengthMenu":[[5,10,20,-1],[5,10,20,"All"]]
        });
    });
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.table-style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/donativo/list.blade.php ENDPATH**/ ?>