

<?php $__env->startSection('css'); ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css"> 

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.css">

    <!-- Font Awesome Icons CSS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!-- Magnific-popup CSS -->
    <link rel="stylesheet" href="css/magnific-popup.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu-active'); ?>
    <li><a href="/">Inicio</a></li>
    <li><a href="/about">Nosotros</a></li>
    <li class="active"><a href="/services">Ongs</a></li>
    <li><a href="work.html">Obras</a></li>
    <li><a href="contact.html">Contactenos</a></li>
    
    <?php if(Route::has('login')): ?>   
    <?php if(auth()->guard()->check()): ?>
        <?php if($user->usuario): ?>
            <li>
                <a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
            </li>
        <?php else: ?>
            <li>
                <a href="<?php echo e(url('/profile/client')); ?>"><?php echo e(__('Perfil')); ?></a>
            </li>
        
            <!-- Authentication -->
            <li>
                <form style="margin-top: 14%" method="POST" action="<?php echo e(url('/logout2')); ?>" x-data>
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(url('/logout2')); ?>" @click.prevent="$root.submit();"><?php echo e(__('Salir')); ?></a>
                </form>
            </li>

        <?php endif; ?>
    <?php else: ?>
        <li>
            <a href="<?php echo e(route('login')); ?>" >Iniciar Sesión</a>
        </li>

    <?php if(Route::has('register')): ?>
        <li>
            <a href="<?php echo e(route('register')); ?>" >Registrarse</a>
        </li>
    <?php endif; ?>

    <?php endif; ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <!-- Home Section -->

    <section id="home" class="main-service">
        <div class="container">
            <div class="row">

                <div class="col-md-12 col-sm-12">
                    <h1 class="wow fadeInUp head" data-wow-delay="0.6s">Lista de ongs</h1>
                    <p class="wow fadeInUp lr-pd" data-wow-delay="0.8s">Aqui podras ver todas las ongs registradas aqui previamente verificadas por nuestro equipo para que puedas donar con toda confianza</p>
                </div>

            </div>
        </div>
    </section>


    <!-- ser section -->

    <section style="margin-bottom: 30px;" class="veg_section layout_padding">
        <div class="container">
          <div class="heading_container heading_center">
            <h2>
              Ongs
            </h2>
            <p>
              Todos ellos necesitan un poco de ayuda busca la que creas que necesitan de tu ayuda y donales lo que puedas ofrecer.
            </p>
          </div>

          <div class="row" style="margin-top: 30px;">
            <?php $__currentLoopData = $ongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-6 col-lg-4">
                <div class="box">
                  <div class="img-box">
                    <img style="max-width: 100%;" src="<?php echo e(asset($ong->fotoOng)); ?>" alt="<?php echo e($ong->nombreOng); ?>">
                  </div>
                  <div class="detail-box">
                    <a href="/services/<?php echo e($ong->id); ?>">
                      <?php echo e($ong->nombreOng); ?>

                    </a>
                    <div class="price_box">
                      <h6 class="price_heading">
                        Donar <span>$$$</span>
                      </h6>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>

          
        </div>
      </section>
    
      <!-- end ser section -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/custom.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/test/list-ong.blade.php ENDPATH**/ ?>