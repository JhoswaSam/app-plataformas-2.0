

<style>
    
    input{
        max-width: 30%;
    }

    .grid--50-50 {
    display: grid;
    grid-template-columns: 50% 50%;
    align-items: center;
    }

    .field input {
    font-size: 16px;
    line-height: 28px;
    padding: 8px 16px;
    width: 100%;
    min-height: 44px;
    border: unset;
    border-radius: 4px;
    outline-color: rgb(84 105 212 / 0.5);
    background-color: rgb(255, 255, 255);
    box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px,
        rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(60, 66, 87, 0.16) 0px 0px 0px 1px,
        rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px,
        rgba(0, 0, 0, 0) 0px 0px 0px 0px;
    }

    .field select {
    font-size: 16px;
    line-height: 28px;
    padding: 8px 16px;
    width: 100%;
    min-height: 44px;
    border: unset;
    border-radius: 4px;
    outline-color: rgb(84 105 212 / 0.5);
    background-color: rgb(255, 255, 255);
    box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px,
        rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(60, 66, 87, 0.16) 0px 0px 0px 1px,
        rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px 0px,
        rgba(0, 0, 0, 0) 0px 0px 0px 0px;
    }

    .formbg {
    margin: 0px auto;
    width: 100%;
    max-width: 448px;
    }
    .padding-horizontal--48 {
    padding: 48px;
    }
    .padding-bottom--24 {
    padding-bottom: 24px;
    }
    .reset-pass a,
    label {
    font-size: 14px;
    font-weight: 600;
    display: block;
    }
    .reset-pass > a {
    text-align: right;
    margin-bottom: 10px;
    }


</style>

<?php $__env->startSection('css'); ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../../css/bootstrap.min.css"> 

    <!-- Main css -->
    <link rel="stylesheet" href="../../css/style.css">

    <!-- Animate CSS -->
    <link rel="stylesheet" href="../../css/animate.css">

    <!-- Font Awesome Icons CSS -->
    <link rel="stylesheet" href="../../css/font-awesome.min.css">

    <!-- Magnific-popup CSS -->
    <link rel="stylesheet" href="../../css/magnific-popup.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu-active'); ?>
    <li><a href="/">Inicio</a></li>
    <li><a href="/about">Nosotros</a></li>
    <li class="active"><a href="/services">Ongs</a></li>
    <li><a href="/work">Obras</a></li>
    <li><a href="contact.html">Contactenos</a></li>
    
    <?php if(Route::has('login')): ?>   
    <?php if(auth()->guard()->check()): ?>
        <?php if($user->usuario): ?>
            <li>
                <a href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
            </li>
        <?php else: ?>
            <li>
                <a href="<?php echo e(url('/profile/client')); ?>"><?php echo e(__('Perfil')); ?></a>
            </li>
        
            <!-- Authentication -->
            <li>
                <form style="margin-top: 20%" method="POST" action="<?php echo e(url('/logout2')); ?>" x-data>
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(url('/logout2')); ?>" @click.prevent="$root.submit();"><?php echo e(__('Salir')); ?></a>
                </form>
            </li>

        <?php endif; ?>
    <?php else: ?>
        <li>
            <a href="<?php echo e(route('login')); ?>" >Iniciar Sesión</a>
        </li>

    <?php if(Route::has('register')): ?>
        <li>
            <a href="<?php echo e(route('register')); ?>" >Registrarse</a>
        </li>
    <?php endif; ?>

    <?php endif; ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="formbg">
    <div class="padding-horizontal--48">
        <div class="container p-0">
            <div class="card px-4">
                <p class="h8 py-3 field padding-bottom--24">Detalles del donativo para <?php echo e($ong->nombreOng); ?></p>
                <div class="row gx-3">
                    <form action="/services/<?php echo e($ong->id); ?>/payment" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 field padding-bottom--24">
                            <div class="d-flex flex-column">
                                <p class="text mb-1">Nombre del donante</p>
                                <input class="form-control mb-3" type="text" required placeholder="Name" value="<?php echo e($user->name); ?>">
                            </div>
                        </div>
                        <div class="col-12 field padding-bottom--24">
                            <div class="d-flex flex-column">
                                <p class="text mb-1">Numero de tarjeta</p>
                                <input class="form-control mb-3" type="text" required placeholder="1234 5678 435678">
                            </div>
                        </div>
                        <div class="col-6 field padding-bottom--24">
                            <div class="d-flex flex-column">
                                <p class="text mb-1">Fecha de expiracion</p>
                                <input class="form-control mb-3" type="text" required placeholder="MM/YYYY">
                            </div>
                        </div>
                        <div class="col-6 field padding-bottom--24">
                            <div class="d-flex flex-column">
                                <p class="text mb-1">CVV/CVC</p>
                                <input class="form-control mb-3 pt-2 " type="password" placeholder="***">
                            </div>
                        </div>
                        <div class="col-6 field padding-bottom--24">
                            <div class="d-flex flex-column">
                                <p class="text mb-1">Monto a donar</p>
                                <input id="cantidad" name="cantidad" class="form-control mb-3 pt-2 " required type="number" placeholder="$$$">
                            </div>
                        </div>
                        <div class="col-6 field padding-bottom--24">
                            <div class="d-flex flex-column">
                                <p class="text mb-1">Mensaje de motivacion</p>
                                <input id="descripcion" name="descripcion" class="form-control mb-3 pt-2 " required type="text" placeholder="Message">
                            </div>
                        </div>
                        

                        <a href="/" class="btn btn-secondary" tabindex="5">Cancelar</a>
                        <button type="submit" class="btn btn-primary" tabindex="4">Donar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="../../js/jquery.js"></script>
    <script src="../../js/bootstrap.min.js"></script>
    <script src="../../js/wow.min.js"></script>
    <script src="../../js/custom.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/test/success-donation.blade.php ENDPATH**/ ?>