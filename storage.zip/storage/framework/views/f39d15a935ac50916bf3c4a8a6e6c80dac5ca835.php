;

<?php $__env->startSection('contenido'); ?>
    <div class="container-fluid">
        <?php $__currentLoopData = $ongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 18rem;">
                <img src="..." class="card-img-top" alt="...">
                <div class="card-body">
                <h5 class="card-title"><?php echo e($ong->nombreOng); ?></h5>
                <p class="card-text"><?php echo e($ong->descripcionOng); ?></p>
                <a href="/list/<?php echo e($ong->id); ?>" class="btn btn-primary">Descripcion</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jhosw\Desktop\Plataformas poryects\app-plataformas\resources\views/client/listong.blade.php ENDPATH**/ ?>