**Task of proyect**

[+] Proteger rutas
[+] Perfil de usuario general
[-] Terminar los componentes del cliente general